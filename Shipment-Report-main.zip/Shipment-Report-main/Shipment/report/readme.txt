create transaction code => ZSHIMPMENT_DEMO

and create excutable program from se38 ZSHIMPMENT_DEMO
 